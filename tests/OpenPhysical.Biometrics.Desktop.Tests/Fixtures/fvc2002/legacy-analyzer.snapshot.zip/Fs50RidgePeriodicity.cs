// SPDX-License-Identifier: GPL-2.0-or-later
namespace OpenPhysical.Biometrics.Capture.Futronic;

internal static class Fs50RidgePeriodicity
{
    internal static byte Measure(ReadOnlySpan<double> profile)
    {
        byte best = 0;
        double strongest = 0.55;
        for (var period = 6; period <= 16; period++)
        {
            var correlation = Correlation(profile, period);
            if (correlation < strongest || Correlation(profile, period / 2) > -0.1)
                continue;
            strongest = correlation;
            best = (byte)period;
        }
        return best;
    }

    private static double Correlation(ReadOnlySpan<double> profile, int lag) =>
        Fs50RidgeCorrelation.Coefficient(profile[..^lag], profile[lag..]);
}

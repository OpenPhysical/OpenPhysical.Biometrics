// SPDX-License-Identifier: GPL-2.0-or-later
namespace OpenPhysical.Biometrics.Capture.Futronic;

internal static class Fs50RidgeEvidence
{
    internal static bool Supports(
        ReadOnlySpan<byte> pixels,
        byte[] mask,
        int[] positions,
        int count
    )
    {
        int left = 800,
            right = 0,
            top = 750,
            bottom = 0;
        for (var i = 0; i < count; i++)
        {
            left = Math.Min(left, positions[i] % 800);
            right = Math.Max(right, positions[i] % 800);
            top = Math.Min(top, positions[i] / 800);
            bottom = Math.Max(bottom, positions[i] / 800);
        }
        Span<byte> evidence = stackalloc byte[50 * 47];
        evidence.Clear();
        for (var y = Math.Max(24, (top / 16 * 16) + 24); y <= Math.Min(725, bottom); y += 16)
        for (var x = Math.Max(24, (left / 16 * 16) + 24); x <= Math.Min(775, right); x += 16)
        {
            var tensor = Tensor(pixels, mask, x, y);
            if (tensor.Count < 768)
                continue;
            if (Coherent(tensor.Xx, tensor.Yy, tensor.Xy))
                evidence[((y / 16) * 50) + (x / 16)] = Period(
                    pixels,
                    x,
                    y,
                    tensor.Xx,
                    tensor.Yy,
                    tensor.Xy
                );
        }
        for(int j=0;j<evidence.Length;j++)if(evidence[j]>0)System.Console.WriteLine($"support x={j%50} y={j/50} period={evidence[j]}"); System.Console.WriteLine($"patch={HasPatch(evidence)}"); return HasPatch(evidence);
    }

    private static bool HasPatch(ReadOnlySpan<byte> evidence)
    {
        for (var y = 1; y < 46; y++)
        for (var x = 1; x < 49; x++)
        {
            var period = evidence[(y * 50) + x];
            if (period == 0)
                continue;
            var neighbors = 0;
            for (var row = y - 1; row <= y + 1; row++)
            for (var column = x - 1; column <= x + 1; column++)
                if (
                    evidence[(row * 50) + column] > 0
                    && Math.Abs(evidence[(row * 50) + column] - period) <= 2
                )
                    neighbors++;
            if (neighbors >= 3)
                return true;
        }
        return false;
    }

    private static (double Xx, double Yy, double Xy, int Count) Tensor(
        ReadOnlySpan<byte> pixels,
        byte[] mask,
        int x,
        int y
    )
    {
        double xx = 0,
            yy = 0,
            xy = 0;
        var count = 0;
        for (var row = y - 16; row < y + 16; row++)
        for (var column = x - 16; column < x + 16; column++)
        {
            var index = (row * 800) + column;
            if (mask[index] == 0)
                continue;
            var (gx, gy) = Gradient(pixels, index);
            xx += gx * gx;
            yy += gy * gy;
            xy += gx * gy;
            count++;
        }
        return (xx, yy, xy, count);
    }

    private static (double X, double Y) Gradient(ReadOnlySpan<byte> pixels, int index) =>
        (
            pixels[index - 799]
                + (2 * pixels[index + 1])
                + pixels[index + 801]
                - pixels[index - 801]
                - (2 * pixels[index - 1])
                - pixels[index + 799],
            pixels[index + 799]
                + (2 * pixels[index + 800])
                + pixels[index + 801]
                - pixels[index - 801]
                - (2 * pixels[index - 800])
                - pixels[index - 799]
        );

    private static bool Coherent(double xx, double yy, double xy) =>
        xx + yy > 0 && Math.Sqrt(((xx - yy) * (xx - yy)) + (4 * xy * xy)) >= (xx + yy) * 0.35;

    private static byte Period(
        ReadOnlySpan<byte> pixels,
        int x,
        int y,
        double xx,
        double yy,
        double xy
    )
    {
        var angle = Math.Atan2(2 * xy, xx - yy) / 2;
        Span<double> profile = stackalloc double[32];
        if (!Fs50RidgeProfile.Create(pixels, x, y, angle, profile))
            return 0;
        double low = 255,
            high = 0;
        for (var i = 0; i < profile.Length; i++)
        {
            low = Math.Min(low, profile[i]);
            high = Math.Max(high, profile[i]);
        }
        return high - low >= 12 && Transitions(profile, low, high) >= 4
            ? Fs50RidgePeriodicity.Measure(profile)
            : (byte)0;
    }

    private static int Transitions(ReadOnlySpan<double> profile, double low, double high)
    {
        int previous = 0,
            count = 0;
        foreach (var value in profile)
        {
            var state =
                value < low + ((high - low) * 0.35) ? -1
                : value > low + ((high - low) * 0.65) ? 1
                : 0;
            if (state == 0)
                continue;
            if (previous != 0 && previous != state)
                count++;
            previous = state;
        }
        return count;
    }
}

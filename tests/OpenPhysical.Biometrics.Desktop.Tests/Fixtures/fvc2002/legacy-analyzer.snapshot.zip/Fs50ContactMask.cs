// SPDX-License-Identifier: GPL-2.0-or-later

namespace OpenPhysical.Biometrics.Capture.Futronic;

using System.Buffers;

internal static class Fs50ContactMask
{
    internal static byte[] Texture(ReadOnlySpan<byte> pixels, bool faint = false)
    {
        const int count = 815 * 765;
        var sums = ArrayPool<long>.Shared.Rent(count);
        var squares = ArrayPool<long>.Shared.Rent(count);
        try
        {
            var mask = new byte[800 * 750];
            _ = Fs50TextureStatistics.Fill(pixels, sums, squares, mask, faint);
            return Fs50MaskMorphology.Apply(mask);
        }
        finally
        {
            ArrayPool<long>.Shared.Return(sums, clearArray: true);
            ArrayPool<long>.Shared.Return(squares, clearArray: true);
        }
    }
}

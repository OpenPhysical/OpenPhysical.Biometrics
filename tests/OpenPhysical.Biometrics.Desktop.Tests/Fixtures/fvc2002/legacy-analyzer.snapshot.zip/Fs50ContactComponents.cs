// SPDX-License-Identifier: GPL-2.0-or-later

namespace OpenPhysical.Biometrics.Capture.Futronic;

using System.Buffers;

internal static class Fs50ContactComponents
{
    internal static (byte[] Mask, int Count, Fs50ContactIssue Issue) Select(
        byte[] mask,
        ReadOnlySpan<byte> pixels
    )
    {
        var queue = ArrayPool<int>.Shared.Rent(mask.Length);
        var best = ArrayPool<int>.Shared.Rent(mask.Length);
        var candidate = ArrayPool<byte>.Shared.Rent(mask.Length);
        Array.Clear(candidate, 0, mask.Length);
        try
        {
            return SelectComponents(mask, pixels, queue, best, candidate);
        }
        finally
        {
            ArrayPool<int>.Shared.Return(queue, clearArray: true);
            ArrayPool<int>.Shared.Return(best, clearArray: true);
            ArrayPool<byte>.Shared.Return(candidate, clearArray: true);
        }
    }

    private static (byte[] Mask, int Count, Fs50ContactIssue Issue) SelectComponents(
        byte[] mask,
        ReadOnlySpan<byte> pixels,
        int[] queue,
        int[] best,
        byte[] candidate
    )
    {
        int count = 0,
            largest = 0,
            rejected = 0;
        var issue = Fs50ContactIssue.None;
        for (var i = 0; i < mask.Length; i++)
        {
            if (mask[i] == 0)
                continue;
            var size = Flood(mask, queue, i);
            if (!Substantial(queue, size))
                continue;
            var observed = Inspect(pixels, candidate, queue, size);
            if (observed != Fs50ContactIssue.None)
            {
                if (size > rejected)
                    (rejected, issue) = (size, observed);
                continue;
            }
            count++;
            if (size <= largest)
                continue;
            largest = size;
            Array.Copy(queue, best, size);
        }
        var output = new byte[mask.Length];
        for (var i = 0; i < largest; i++)
            output[best[i]] = 1;
        return (output, count, count > 0 ? Fs50ContactIssue.None : issue);
    }

    private static Fs50ContactIssue Inspect(
        ReadOnlySpan<byte> pixels,
        byte[] mask,
        int[] positions,
        int count
    )
    {
        for (var i = 0; i < count; i++)
            mask[positions[i]] = 1;
        var issue = Fs50ContactEvidence.Assess(pixels, mask, positions, count);
        for (var i = 0; i < count; i++)
            mask[positions[i]] = 0;
        return issue;
    }

    private static bool Substantial(int[] positions, int count)
    {
        if (count < 4000)
            return false;
        int minX = 800,
            maxX = 0,
            minY = 750,
            maxY = 0;
        for (var i = 0; i < count; i++)
        {
            minX = Math.Min(minX, positions[i] % 800);
            maxX = Math.Max(maxX, positions[i] % 800);
            minY = Math.Min(minY, positions[i] / 800);
            maxY = Math.Max(maxY, positions[i] / 800);
        }
        return maxX - minX + 1 >= 40 && maxY - minY + 1 >= 80;
    }

    private static int Flood(byte[] mask, int[] queue, int start)
    {
        int head = 0,
            tail = 1;
        queue[0] = start;
        mask[start] = 0;
        while (head < tail)
        {
            var index = queue[head++];
            int x = index % 800,
                y = index / 800;
            for (var yy = Math.Max(0, y - 1); yy <= Math.Min(749, y + 1); yy++)
            for (var xx = Math.Max(0, x - 1); xx <= Math.Min(799, x + 1); xx++)
            {
                var next = yy * 800 + xx;
                if (mask[next] == 0)
                    continue;
                mask[next] = 0;
                queue[tail++] = next;
            }
        }
        return tail;
    }
}

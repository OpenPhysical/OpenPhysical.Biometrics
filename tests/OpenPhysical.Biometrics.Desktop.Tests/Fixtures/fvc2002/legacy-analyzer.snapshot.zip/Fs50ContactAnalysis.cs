// SPDX-License-Identifier: GPL-2.0-or-later

namespace OpenPhysical.Biometrics.Capture.Futronic;

using CSharpFunctionalExtensions;

/// <summary>Finds substantial ridge contact while rejecting faint texture and unstructured marks.</summary>
public static class Fs50ContactAnalysis
{
    /// <summary>Analyzes unchanged pixels using texture, connected area, darkness and local ridge evidence.</summary>
    /// <param name="pixels">Complete 800 by 750 corrected image.</param>
    /// <returns>Contact statistics or a geometry failure.</returns>
    public static Result<Fs50ContactRegion, CaptureError> Analyze(ReadOnlySpan<byte> pixels)
    {
        if (pixels.Length != 800 * 750)
            return new CaptureError(
                CaptureErrorCodes.UnsupportedGeometry,
                "Contact analysis requires a complete corrected FS50 image."
            );
        var components = Fs50ContactComponents.Select(Fs50ContactMask.Texture(pixels), pixels);
        if (components.Count == 0 && components.Issue == Fs50ContactIssue.None)
            components = Fs50ContactComponents.Select(
                Fs50ContactMask.Texture(pixels, true),
                pixels
            );
        var mask = components.Mask;
        var histogram = new int[256];
        int area = 0;
        for (int i = 0; i < mask.Length; i++)
            if (mask[i] != 0)
            {
                area++;
                histogram[pixels[i]]++;
            }
        double low = Percentile(histogram, area, 0.05);
        double high = Percentile(histogram, area, 0.95);
        return new Fs50ContactRegion(
            mask,
            area,
            high - low,
            area == 0 ? 0 : 255 - low,
            components.Count,
            components.Issue
        );
    }

    private static double Percentile(int[] histogram, int count, double fraction)
    {
        if (count == 0)
            return 0;
        double position = (count - 1) * fraction;
        int lower = (int)position,
            upper = (int)Math.Ceiling(position);
        int seen = 0,
            low = 0;
        for (int i = 0; i < histogram.Length; i++)
        {
            int next = seen + histogram[i];
            if (seen <= lower && next > lower)
                low = i;
            if (next > upper)
                return low + ((i - low) * (position - lower));
            seen = next;
        }
        return 255;
    }
}

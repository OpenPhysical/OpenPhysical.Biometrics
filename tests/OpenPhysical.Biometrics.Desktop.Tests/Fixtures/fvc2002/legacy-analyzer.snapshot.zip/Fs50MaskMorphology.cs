// SPDX-License-Identifier: GPL-2.0-or-later

namespace OpenPhysical.Biometrics.Capture.Futronic;

using System.Buffers;

internal static class Fs50MaskMorphology
{
    internal static byte[] Apply(byte[] mask)
    {
        var temporary = ArrayPool<byte>.Shared.Rent(mask.Length);
        var integral = ArrayPool<int>.Shared.Rent(801 * 751);
        try
        {
            _ = Morph(mask, temporary, integral, 6, true);
            _ = Morph(temporary, mask, integral, 6, false);
            _ = Morph(mask, temporary, integral, 3, false);
            _ = Morph(temporary, mask, integral, 3, true);
            return mask;
        }
        finally
        {
            ArrayPool<byte>.Shared.Return(temporary, clearArray: true);
            ArrayPool<int>.Shared.Return(integral, clearArray: true);
        }
    }

    private static bool Morph(byte[] mask, byte[] output, int[] integral, int radius, bool dilate)
    {
        _ = Integrate(mask, integral);
        for (var y = 0; y < 750; y++)
        for (var x = 0; x < 800; x++)
        {
            int left = Math.Max(0, x - radius),
                top = Math.Max(0, y - radius);
            int right = Math.Min(800, x + radius + 1),
                bottom = Math.Min(750, y + radius + 1);
            var count =
                integral[bottom * 801 + right]
                - integral[top * 801 + right]
                - integral[bottom * 801 + left]
                + integral[top * 801 + left];
            output[y * 800 + x] = (byte)(
                (dilate ? count > 0 : count == (right - left) * (bottom - top)) ? 1 : 0
            );
        }
        return true;
    }

    private static bool Integrate(byte[] mask, int[] integral)
    {
        Array.Clear(integral, 0, 801);
        for (var y = 0; y < 750; y++)
        {
            var sum = 0;
            var row = (y + 1) * 801;
            integral[row] = 0;
            for (var x = 0; x < 800; x++)
            {
                sum += mask[y * 800 + x];
                integral[row + x + 1] = integral[row - 801 + x + 1] + sum;
            }
        }
        return true;
    }
}

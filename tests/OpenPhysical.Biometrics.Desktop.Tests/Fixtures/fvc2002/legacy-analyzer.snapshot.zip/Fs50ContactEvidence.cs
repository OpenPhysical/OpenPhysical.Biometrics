// SPDX-License-Identifier: GPL-2.0-or-later
namespace OpenPhysical.Biometrics.Capture.Futronic;

internal static class Fs50ContactEvidence
{
    internal static Fs50ContactIssue Assess(
        ReadOnlySpan<byte> pixels,
        byte[] mask,
        int[] positions,
        int count
    )
    {
        Span<int> histogram = stackalloc int[256];
        histogram.Clear();
        for (var i = 0; i < count; i++)
            histogram[pixels[positions[i]]]++;
        var seen = 0;
        for (var value = 0; value < 256; value++)
        {
            seen += histogram[value];
            if (seen <= (count - 1) * 0.05)
                continue;
            if (value > 205)
                return Fs50ContactIssue.TooLight;
            break;
        }
        return Fs50RidgeEvidence.Supports(pixels, mask, positions, count)
            ? Fs50ContactIssue.None
            : Fs50ContactIssue.InsufficientRidgeEvidence;
    }
}

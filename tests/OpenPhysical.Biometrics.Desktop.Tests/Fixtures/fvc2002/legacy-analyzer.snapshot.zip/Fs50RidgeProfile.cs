// SPDX-License-Identifier: GPL-2.0-or-later
namespace OpenPhysical.Biometrics.Capture.Futronic;

internal static class Fs50RidgeProfile
{
    internal static bool Create(
        ReadOnlySpan<byte> pixels,
        int x,
        int y,
        double angle,
        Span<double> profile
    )
    {
        double cosine = Math.Cos(angle),
            sine = Math.Sin(angle);
        Span<double> first = stackalloc double[32];
        Span<double> second = stackalloc double[32];
        for (var i = 0; i < profile.Length; i++)
        {
            double left = 0,
                right = 0;
            for (var tangent = -2; tangent <= 2; tangent++)
            {
                left += Sample(pixels, x, y, i - 15.5, tangent - 8, cosine, sine);
                right += Sample(pixels, x, y, i - 15.5, tangent + 8, cosine, sine);
            }
            first[i] = left / 5;
            second[i] = right / 5;
            profile[i] = (left + right) / 10;
        }
        for (var shift = -3; shift <= 3; shift++)
        {
            var length = profile.Length - Math.Abs(shift);
            if (
                Fs50RidgeCorrelation.Coefficient(
                    first.Slice(Math.Max(0, shift), length),
                    second.Slice(Math.Max(0, -shift), length)
                ) >= 0.55
            )
                return true;
        }
        return false;
    }

    private static byte Sample(
        ReadOnlySpan<byte> pixels,
        int x,
        int y,
        double normal,
        int tangent,
        double cosine,
        double sine
    )
    {
        var px = (int)Math.Round(x + (normal * cosine) - (tangent * sine));
        var py = (int)Math.Round(y + (normal * sine) + (tangent * cosine));
        return pixels[(py * 800) + px];
    }
}
